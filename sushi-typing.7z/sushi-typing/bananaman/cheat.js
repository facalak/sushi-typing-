function toggleCheat() {
  const cheat = document.getElementById("cheatMenu");
  cheat.style.display = cheat.style.display === "none" ? "block" : "none";
}

function applyScore() {
  const value = parseInt(document.getElementById("setScore").value);
  if (!isNaN(value)) {
    score = value;
    scoreDiv.textContent = "スコア: " + score;
  }
}

function applySushi() {
  const name = document.getElementById("setSushi").value.trim();
  if (name) {
    newSushi(name);
  }
}

function autoAnswer() {
  input.value = current;
  input.dispatchEvent(new Event("input"));
}

// ✅ 新機能①: 時計を増やす
function addTime(seconds = 5) {
  if (typeof timeLeft !== 'undefined') {
    timeLeft += seconds;
    updateTimerDisplay();
  }
}

// ✅ 新機能②: 言葉を追加
function addNewWord() {
  const word = document.getElementById("addWord").value.trim();
  if (word && !sushiList.includes(word)) {
    sushiList.push(word);
    alert("新しい寿司ネタを追加しました: " + word);
  }
}

// ✅ 新機能③: 現在の残り時間を表示（コンソール）
function showTimeInConsole() {
  console.log("現在の残り時間: " + timeLeft + "秒");
}
