const sushiList = ["まぐろ", "サーモン", "いくら", "たまご", "えび", "はまち", "たい", "あじ", "うに", "こはだ"];
let current = "";
let score = 0;
let timeLeft = 30; // 制限時間（秒）
let timerInterval = null;
let gameEnded = false;

const sushiDiv = document.getElementById("sushi");
const input = document.getElementById("input");
const scoreDiv = document.getElementById("score");
const timerDiv = document.createElement("div");
timerDiv.style.fontSize = "18px";
timerDiv.style.margin = "10px";
document.body.insertBefore(timerDiv, sushiDiv);

// スタート時に呼ばれる
function startGame() {
  score = 0;
  timeLeft = 30;
  gameEnded = false;
  input.disabled = false;
  input.value = "";
  input.focus();
  scoreDiv.textContent = "スコア: 0";
  newSushi();
  updateTimerDisplay();
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(countDown, 1000);
}

// タイマー表示を更新
function updateTimerDisplay() {
  timerDiv.textContent = `残り時間: ${timeLeft} 秒`;
}

// 1秒ごとに呼ばれる
function countDown() {
  timeLeft--;
  updateTimerDisplay();
  if (timeLeft <= 0) {
    endGame();
  }
}

// ゲーム終了
function endGame() {
  clearInterval(timerInterval);
  gameEnded = true;
  sushiDiv.textContent = "🍣 終了！";
  input.disabled = true;
  scoreDiv.textContent = `最終スコア: ${score}`;
  
  const restartBtn = document.createElement("button");
  restartBtn.textContent = "もう一回プレイ";
  restartBtn.style.marginTop = "20px";
  restartBtn.onclick = () => {
    restartBtn.remove();
    startGame();
  };
  document.body.appendChild(restartBtn);
}

// 寿司ネタを出す
function newSushi(forced = null) {
  current = forced || sushiList[Math.floor(Math.random() * sushiList.length)];
  sushiDiv.textContent = "🍣 " + current;
}

// タイピング入力イベント
input.addEventListener("input", () => {
  if (gameEnded) return;

  if (input.value === current) {
    score++;
    scoreDiv.textContent = "スコア: " + score;
    input.value = "";
    newSushi();
  }
});

// 初期化
startGame();

